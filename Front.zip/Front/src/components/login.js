import React from "react";
import { Redirect } from "react-router-dom";

class Login extends React.Component {
  constructor() {
    super();
    this.state = {
      condition: false,
      tipousuario: '',
      usuario: '',
      password: '',
      error: ''
    };
  }

  validar = () => {
    const { usuario, password } = this.state;

    fetch(`http://localhost:9999/Login?User=${usuario}&password=${password}`)
      .then(response => response.json())
      .then(usuario => {
        if (usuario.status === "yes") {
          this.setState({ error: '' }); 
          if (usuario.tipo === "administrador") {
            this.setState({ condition: true, tipousuario: "administrador" });
          } else if (usuario.tipo === "profesor") {
            this.setState({ condition: true, tipousuario: "profesor" });
          } else if (usuario.tipo === "alumno") {
            this.setState({ condition: true, tipousuario: "alumno" });
          } else {
            this.setState({ error: "Tipo de usuario no reconocido" });
          }
        } else {
          this.setState({
            error: "Usuario o contraseña incorrectos",
            usuario: '',//Limpiar campos
            password: ''
          });
        }
      })
      .catch(error => {
        console.error("Error de conexión:", error);
        this.setState({ error: "Error de servidor. Intente más tarde." });
      });
  };

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  }

  render() {
    const { condition, tipousuario, usuario, password, error } = this.state;

    if (condition && tipousuario === "administrador") {
      return <Redirect to="/administrador" />;
    }
    if (condition && tipousuario === "profesor") {
      return <Redirect to="/profesor" />;
    }
    if (condition && tipousuario === "alumno") {
      return <Redirect to="/alumno" />;
    }

    return (
      <div className="center-container" style={{ padding: '5px' }}>
        <h1 className="AlignCenter">LOGIN</h1>

        <div className="form-group">
          <label className="form-label" htmlFor="User">Usuario</label>
          <input
            placeholder="Ingrese el usuario"
            type="text"
            id="User"
            name="usuario"
            value={usuario}
            onChange={this.handleChange}
            className="form-control"
          />
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="password">Password</label>
          <input
            placeholder="Ingrese su contraseña"
            type="password"
            id="password"
            name="password"
            value={password}
            onChange={this.handleChange}
            className="form-control"
          />
        </div>

        {error && <div style={{ color: 'red', marginTop: '10px' }}>{error}</div>}

        <button className="btn btn-primary" onClick={this.validar}>
          Submit
        </button>

        <div className="team-names" style={{ padding: '5px' }}>
          <p>Integrantes del equipo:</p>
          <ul>
            <li>Daniel Muñoz</li>
            <li>Alejandra Vilchez</li>
            <li>Evelyn Pinales</li>
          </ul>
        </div>
      </div>
    );
  }
}

export default Login;
