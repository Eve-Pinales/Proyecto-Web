import React from "react";
import { Button, Container } from "react-bootstrap";
import axios from "axios";
import { Link } from "react-router-dom";
//import '../styles/styles.css'; 

class Info extends React.Component {

    state = {
        data: []
    }

    componentDidMount() {
        const qId = new URLSearchParams(window.location.search).get("id");
        if (qId) {
            axios.get("http://localhost:9999/Pregunta?id=" + qId + "").then(response => {
                this.setState({ data: response.data });
            }).catch(error => {
                console.info(error);
            })
        }
    }

    render() {
        const { data } = this.state;
        return (
            <Container className="MarginContainer">
                <h3>Informacion del texto</h3>
                
                {data.length > 0 ? (
                    <div className="tabla-container">
                        <table className="tabla-textos">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Texto</th>
                                    <th>Sentimiento</th>
                                </tr>
                            </thead>
                            <tbody>
                                {data.map((texto, index) => {
                                    console.log("Texto:" + texto.sentimiento);
                                    return (
                                        <tr key={texto.id || index}>
                                            <td>{texto.id}</td>
                                            <td>{texto.texto}</td>
                                            <td>
                                                <span className={`sentimiento-badge ${
                                                    texto.sentimiento === 'positivo' 
                                                        ? 'sentimiento-positivo'
                                                        : texto.sentimiento === 'negativo'
                                                        ? 'sentimiento-negativo'
                                                        : 'sentimiento-neutral'
                                                }`}>
                                                    {texto.sentimiento}
                                                </span>
                                            </td>
                                        </tr>
                                    )
                                })}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <div className="no-datos">No hay datos para mostrar</div>
                )}
                
                <Button
                    variant="success"
                    className="M-6">
                    <Link to={`/administrador`} className="CustomLink">
                        CRUD DEL ADMINISTRADOR
                    </Link>
                </Button>
            </Container>
        )
    }
}

export default Info;