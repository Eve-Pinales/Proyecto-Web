import React from "react";
import { Button } from "react-bootstrap";
import { Link } from "react-router-dom";

const Pregunta = ({ id, texto }) => {
    return (
        <tr>
            <td>{texto}</td>
            <td className="AlignCenter">
                <Button
                    variant="success"
                    className="M-6">
                    <Link to={`/info?id=${id}`} className="CustomLink" >
                        Ver texto
                    </Link>
                </Button>
                <Button
                    variant="warning"
                    className="M-6">
                    <Link to={`/editar?id=${id}`} className="CustomLink" >
                        Editar texto
                    </Link>
                </Button>
                <Button
                    variant="danger"
                    className="M-6">
                    <Link to={`/eliminar?id=${id}`} className="CustomLink" >
                        Eliminar texto
                    </Link>                    
                </Button>
            </td>
        </tr>
    )
}
export default Pregunta;