import React from "react";
import { Button, Container } from "react-bootstrap";
import axios from "axios";
import { Link } from "react-router-dom";

class Eliminar extends React.Component {
  state = {
    data: [],
    eliminado: false
  }

  componentDidMount() {
    const qId = new URLSearchParams(window.location.search).get("id");
    if (qId) {
      axios.get("http://localhost:9999/Pregunta?id=" + qId)
        .then(response => {
          this.setState({ data: response.data });
        })
        .catch(error => {
          console.error("Error al obtener el texto:", error);
        });
    }
  }

  eliminarPregunta = () => {
    const qId = new URLSearchParams(window.location.search).get("id");
    if (qId) {
      axios.delete("http://localhost:9999/eliminar?id=" + qId)
        .then(() => {
          alert("Texto eliminado correctamente");
          this.setState({ eliminado: true });
        })
        .catch(error => {
          console.error("Error al eliminar el texto:", error);
        });
    }
  }

  render() {
    const { data, eliminado } = this.state;
    if (eliminado) {
      //return <Navigate to="/administrador" replace />;
      return (<Button as={Link} to="/administrador" variant="success" className="d-block mx-auto mt-3">
        Volver al administrador</Button>)
    }

    return (
      <Container className="MarginContainer">
        <h3>¿Estás seguro que deseas eliminar este texto?</h3>
        {
          data.map(texto => (
            <div key={texto.id}>
              <p><strong>ID:</strong> {texto.id}</p>
              <p><strong>Texto:</strong> {texto.texto}</p>
              <p><strong>Respuesta:</strong> {texto.sentimiento}</p>
            </div>
          ))
        }
        <Button variant="danger" onClick={this.eliminarPregunta}>
        Eliminar definitivamente
        </Button>
        <Button variant="secondary" className="ms-2">
          <Link to="/administrador" className="CustomLink">
            Cancelar y volver
          </Link>
        </Button>
      </Container>
    );
  }
}

export default Eliminar;
