import React from "react";
import { Button, Container } from "react-bootstrap";
import axios from "axios";
import { Link } from "react-router-dom";

class Editar extends React.Component {
  state = {
    texto: "",
    editado: false
  };

  componentDidMount() {
    const qId = new URLSearchParams(window.location.search).get("id");
    if (qId) {
      axios.get("http://localhost:9999/Pregunta?id=" + qId)
        .then(response => {
          const datos = response.data[0];
          this.setState({
            texto: datos.texto
          });
        })
        .catch(error => {
          console.error("Error al obtener el texto:", error);
        });
    }
  }

  handleChange = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.editarPregunta();
  }

  editarPregunta = () => {
    const qId = new URLSearchParams(window.location.search).get("id");
    const {texto} = this.state;
    axios.put("http://localhost:9999/editar?id=" + qId, {
      texto
    })
      .then(() => {
        alert("Texto editado correctamente");
        this.setState({ editado: true });
      })
      .catch(error => {
        console.error("Error al editar el texto:", error);
      });
  }

  render() {
    const {texto} = this.state;

    return (
      <Container className="MarginContainer">
        <form className="encuesta" onSubmit={this.handleSubmit}>
          <h3>Edición del texto</h3>

          <article className="p1">
            <section>
              <h5>Texto</h5>
              <label htmlFor="texto">Ingrese el texto:</label>
              <input
                type="text"
                id="texto"
                name="texto"
                value={texto}
                onChange={this.handleChange}
                required
              />
            </section>
          </article>
          <aside>
            <p>Presione el botón para enviar</p>
          </aside>

          <button type="submit">Enviar</button>

          <footer>¡Gracias!</footer>
        </form>

        <Button variant="success" className="M-6">
          <Link to="/administrador" className="CustomLink">
            CRUD DEL ADMINISTRADOR
          </Link>
        </Button>
      </Container>
    );
  }
}

export default Editar;
