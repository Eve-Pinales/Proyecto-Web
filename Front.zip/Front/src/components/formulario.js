import React from "react";
import { Container, Button } from 'react-bootstrap';
import { Link } from "react-router-dom";
import axios from 'axios';

class Formulario extends React.Component {
    state = {
        texto: ''
    };

    handleChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    };

    handleSubmit = (e) => {
        e.preventDefault();

        const {texto} = this.state;

        axios.post("http://localhost:9999/formulario", {
            texto
        }).then(() => {
            alert("Texto ingresado correctamente");
            this.setState({ texto: ''}); // limpiar formulario
        }).catch(error => {
            console.info(error);
            alert("Hubo un error al enviar el texto");
        });
    };

    render() {
        const {texto} = this.state;

        return (
            <Container className="MarginContainer">
                <form className="encuesta" onSubmit={this.handleSubmit}>
                    <h3>Ingreso de nuevo texto</h3>

                    <article className="p1">
                        <section>
                            <h5>texto</h5>    
                            <label htmlFor="texto">Ingrese el texto a clasificar:</label>
                            <input
                                type="text"
                                id="texto"
                                name="texto"
                                value={texto}
                                onChange={this.handleChange}
                                required
                            />
                        </section>    
                    </article>    

                    <aside>
                        <p>Presione el botón para enviar</p>
                    </aside>

                    <button type="submit">Enviar</button>

                    <footer>¡Gracias!</footer>
                </form>

                <Button variant="success" className="M-6">
                    <Link to="/administrador" className="CustomLink">
                        CRUD DEL ADMINISTRADOR
                    </Link>
                </Button>
            </Container>
        );
    }
}

export default Formulario;
