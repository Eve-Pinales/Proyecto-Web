import React from "react";
import {
    Switch,
    Route,
} from "react-router-dom";
import Home from "./components/home";
import Administrador from "./components/administrador";
import Info from "./components/info";
import 'bootstrap/dist/css/bootstrap.min.css';
import "./styles/styles.css";
import Login from "./components/login";
import Formulario from "./components/formulario";
import Editar from "./components/editar";
import Eliminar from "./components/eliminar";

const App = () => {
    return (
        <div>
            <Switch>
                <Route exact path="/">
                    <Login />
                </Route>
                <Route exact path="/home">
                    <Home />
                </Route>
                <Route exact path="/administrador">
                    <Administrador />
                </Route> 
                <Route exact path="/formulario">
                    <Formulario />
                </Route>  
                <Route exact path="/info">
                    <Info />
                </Route> 
                <Route exact path="/editar">
                    <Editar />
                </Route> 
                <Route exact path="/eliminar">
                    <Eliminar />
                </Route> 
                                                                                                
                <Route path="*" render={() => <h1>RECURSO NO ENCONTRADO</h1>} />
            </Switch>
        </div>
    );
}
export default App;