const express = require("express");
const app = express();
const puerto = 9999;
const url = require("url");

// Importar modelos y configuración
const { Login, TablaJson, syncDatabases } = require('./models');
const seedData = require('./seeders/initial-data');

app.use(express.static('public'));
app.use(express.json());

// Inicializar base de datos al arrancar servidor
const initializeDatabase = async () => {
  await syncDatabases();
  await seedData();
};

// RUTAS CON SEQUELIZE

app.get("/Pregunta", async (request, response) => {
  try {
    const q = url.parse(request.url, true).query;
    response.setHeader('Cache-control', 'no-cache');
    response.writeHead(200, {'Content-Type': 'application/json'});
    console.log("METODO GET Y PREGUNTA");
    
    const id = q.id;
    const resultado = await TablaJson.findOne({
      where: { idEjercicio: id }
    });

    if (resultado) {
      const cadenajsonfinal = `[${JSON.stringify(resultado.columnajson)}]`;
      response.end(cadenajsonfinal);
    } else {
      response.end('[]');
    }
  } catch (error) {
    console.error("Error en /Pregunta:", error);
    response.status(500).json({ error: "Error interno del servidor" });
  }
});

app.get("/Preguntas", async (request, response) => {
  try {
    response.setHeader('Cache-control', 'no-cache');
    response.writeHead(200, {'Content-Type': 'application/json'});
    console.log("METODO GET Y PREGUNTAS");
    
    const resultados = await TablaJson.findAll();
    
    if (resultados.length > 0) {
      const jsonArray = resultados.map(item => item.columnajson);
      response.end(JSON.stringify(jsonArray));
    } else {
      response.end('[]');
    }
  } catch (error) {
    console.error("Error en /Preguntas:", error);
    response.status(500).json({ error: "Error interno del servidor" });
  }
});

app.get("/Login", async (request, response) => {
  try {
    const q = url.parse(request.url, true).query;
    response.setHeader('Cache-control', 'no-cache');
    response.writeHead(200, {'Content-Type': 'application/json'});
    console.log("METODO GET Y LOGIN");
    
    const user = q.User;
    const password = q.password;
    
    const usuario = await Login.findOne({
      where: {
        USERNAME: user,
        PASSWORD: password
      }
    });

    if (usuario) {
      const respuesta = {
        status: "yes",
        tipo: usuario.TIPOUSUARIO
      };
      console.log(JSON.stringify(respuesta));
      response.end(JSON.stringify(respuesta));
    } else {
      const respuesta = {
        status: "no",
        tipo: "nodefinido"
      };
      console.log(JSON.stringify(respuesta));
      response.end(JSON.stringify(respuesta));
    }
  } catch (error) {
    console.error("Error en /Login:", error);
    response.status(500).json({ error: "Error interno del servidor" });
  }
});

app.post("/formulario", async (req, res) => {
  try {
    const nuevaPregunta = req.body;
    console.log("METODO POST Y CREAR");
    
    if (!nuevaPregunta || Object.keys(nuevaPregunta).length === 0) {
      return res.status(400).json({ error: "Datos incompletos" });
    }

    // Obtener el máximo ID
    const maxResult = await TablaJson.max('idEjercicio');
    const nuevoId = (maxResult || 0) + 1;
    
    // Asignar ID al JSON
    nuevaPregunta.id = String(nuevoId);

    // Crear nuevo registro
    const nuevoRegistro = await TablaJson.create({
      idEjercicio: nuevoId,
      columnajson: nuevaPregunta
    });

    res.status(200).json({
      status: "texto agregado correctamente",
      id: nuevoRegistro.idEjercicio
    });
  } catch (error) {
    console.error("Error en /formulario:", error);
    res.status(500).json({ error: "Error al crear texto" });
  }
});

app.put("/editar", async (req, res) => {
  try {
    const id = req.query.id;
    const { texto } = req.body; // Cambiado de 'pregunta' a 'texto' para coincidir con el frontend
    console.log("METODO PUT Y EDITAR");

    if (!id || !texto) {
      return res.status(400).json({ error: "Faltan datos" });
    }

    // Buscar el registro
    const registro = await TablaJson.findOne({
      where: {
        idEjercicio: id
      }
    });

    if (!registro) {
      return res.status(404).json({ error: "Texto no encontrado" });
    }

    // Actualizar el JSON
    const jsonActualizado = {
      ...registro.columnajson,
      texto: texto // Cambiado de 'texto: texto' que estaba mal
    };

    // Guardar cambios
    await registro.update({
      columnajson: jsonActualizado
    });

    res.status(200).json({ status: "Texto actualizado correctamente" });
  } catch (error) {
    console.error("Error en /editar:", error);
    res.status(500).json({ error: "Error al actualizar texto" });
  }
});

app.delete("/eliminar", async (request, response) => {
  try {
    const q = url.parse(request.url, true).query;
    const id = parseInt(q.id);
    
    if (!id) {
      return response.status(400).json({ error: "Falta el parámetro id" });
    }
    
    console.log("METODO DELETE");

    // Verificar que el registro existe antes de eliminarlo
    const registroAEliminar = await TablaJson.findOne({
      where: { idEjercicio: id }
    });

    if (!registroAEliminar) {
      return response.status(404).json({ error: "texto no encontrada" });
    }

    // Eliminar el registro
    await TablaJson.destroy({
      where: { idEjercicio: id }
    });

    // Obtener TODOS los registros con ID mayor al eliminado
    const registrosPosteriores = await TablaJson.findAll({
      where: {
        idEjercicio: {
          [require('sequelize').Op.gt]: id
        }
      },
      order: [['idEjercicio', 'ASC']]
    });

    // Reorganizar IDs: cada registro se desplaza una posición hacia abajo
    for (let i = 0; i < registrosPosteriores.length; i++) {
      const registro = registrosPosteriores[i];
      const nuevoId = id + i; // El primer registro toma el ID eliminado, el siguiente id+1, etc.
      
      // Actualizar JSON interno si existe
      let jsonActualizado = registro.columnajson;
      if (jsonActualizado && typeof jsonActualizado === 'object') {
        jsonActualizado = {
          ...jsonActualizado,
          id: String(nuevoId)
        };
      }

      // Actualizar registro en la base de datos
      await registro.update({
        idEjercicio: nuevoId,
        columnajson: jsonActualizado
      });
    }

    response.status(200).json({
      status: "Texto eliminado y IDs reorganizados",
      eliminado: id,
      registrosActualizados: registrosPosteriores.length
    });
    
  } catch (error) {
    console.error("Error en /eliminar:", error);
    response.status(500).json({ error: "Error al eliminar texto" });
  }
});

// Inicializar servidor
app.listen(puerto, async () => {
  console.log(`Servidor corriendo en puerto ${puerto}`);
  await initializeDatabase();
});