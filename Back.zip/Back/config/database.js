const { Sequelize } = require('sequelize');

// Configuración de base de datos usuarios
const sequelizeUsuarios = new Sequelize('usuarios', 'root', '1234', {
  host: 'localhost',
  dialect: 'mysql',
  logging: false
});

// Configuración de base de datos crudjson
const sequelizeCrudJson = new Sequelize('crudjson', 'root', '1234', {
  host: 'localhost',
  dialect: 'mysql',
  logging: false
});

module.exports = {
  sequelizeUsuarios,
  sequelizeCrudJson
};