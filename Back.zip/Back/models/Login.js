const { DataTypes } = require('sequelize');
const { sequelizeUsuarios } = require('../config/database');

const Login = sequelizeUsuarios.define('Login', {
  idLOGIN: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
    field: 'idLOGIN'
  },
  USERNAME: {
    type: DataTypes.STRING(45),
    allowNull: true
  },
  PASSWORD: {
    type: DataTypes.STRING(45),
    allowNull: true
  },
  TIPOUSUARIO: {
    type: DataTypes.STRING(45),
    allowNull: true
  }
}, {
  tableName: 'login',
  timestamps: false 
});

module.exports = Login;