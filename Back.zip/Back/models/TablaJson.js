const { DataTypes } = require('sequelize');
const { sequelizeCrudJson } = require('../config/database');

const TablaJson = sequelizeCrudJson.define('TablaJson', {
  idEjercicio: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
    field: 'idEjercicio'
  },
  columnajson: {
    type: DataTypes.JSON,
    allowNull: true
  }
}, {
  tableName: 'tablajson',
  timestamps: false
});

module.exports = TablaJson;