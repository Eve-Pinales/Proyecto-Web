const { sequelizeUsuarios, sequelizeCrudJson } = require('../config/database');
const Login = require('./Login');
const TablaJson = require('./TablaJson');

// Función para sincronizar bases de datos
const syncDatabases = async () => {
  try {
    // Autenticar conexiones
    await sequelizeUsuarios.authenticate();
    await sequelizeCrudJson.authenticate();
    console.log('Conexiones a bases de datos establecidas correctamente.');

    // Sincronizar modelos (crear tablas si no existen)
    await sequelizeUsuarios.sync();
    await sequelizeCrudJson.sync();
    console.log('Modelos sincronizados correctamente.');

  } catch (error) {
    console.error('Error al conectar con las bases de datos:', error);
  }
};

module.exports = {
  Login,
  TablaJson,
  sequelizeUsuarios,
  sequelizeCrudJson,
  syncDatabases
};