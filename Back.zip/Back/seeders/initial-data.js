const { Login, TablaJson } = require('../models');

const seedData = async () => {
  try {
    // Verificar si ya existen datos
    const loginCount = await Login.count();
    const tablaJsonCount = await TablaJson.count();

    // Insertar datos iniciales solo si no existen
    if (loginCount === 0) {
      await Login.create({
        USERNAME: 'admin',
        PASSWORD: '1234',
        TIPOUSUARIO: 'administrador'
      });
      console.log('Usuario admin creado');
    }

    if (tablaJsonCount === 0) {
      await TablaJson.create({
        columnajson: {
          id: "1",
          texto: "Te amo",
          sentimiento: "es positivo"
        }
      });
      await TablaJson.create({
        columnajson: {
          id: "2",
          texto: "Te odio",
          sentimiento: "es negativo"
        }
      })
      console.log('Dato inicial en tablajson creado');
    }

    console.log('Datos iniciales verificados/insertados correctamente');
  } catch (error) {
    console.error('Error al insertar datos iniciales:', error);
  }
};

module.exports = seedData;